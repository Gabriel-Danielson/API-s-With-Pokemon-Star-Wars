﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PokeAPI;

namespace PokemonExercise
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
        }

        /// <summary> Connects to API and fetches an inputted pokemon to assign its information to labels.</summary>
        /// <param name="accountNumber">The name of the pokemon being fetched</param>
        private async void GetSpecies(string query)
        {
            // Try/catch block for exceptions
            try
            {
                PokemonSpecies pokemon = await DataFetcher.GetNamedApiObject<PokemonSpecies>(query);

                //Displays pokemon info
                lbl_Name.Text = "Name: " + pokemon.Name;
                lbl_Happiness.Text = "Base Happiness: " + pokemon.BaseHappiness;
                lbl_CaptureRate.Text = "Capture Rate: " + pokemon.CaptureRate;
                lbl_Habitat.Text = "Habitat: " + (pokemon.Habitat?.Name ?? "No habitats listed");
                lbl_GrowthRate.Text = "Growth Rate: " + pokemon.GrowthRate?.Name ?? "No growth rate listed";
                lbl_FlavorText.Text = "FlavorText: " + pokemon.FlavorTexts?.FirstOrDefault().FlavorText ?? "No flavor texts listed";
                lbl_EggGroups.Text = "Egg Groups: " + pokemon.EggGroups?.Any();

                //Runs if there is an egg group, adds all groups to a list and displays them
                if (pokemon.EggGroups != null && pokemon.EggGroups.Any())
                {
                    List<string> eggGroupNames = new List<string>();
                    foreach (var eggGroup in pokemon.EggGroups)
                    {
                        eggGroupNames.Add(eggGroup.Name);
                    }
                    lbl_EggGroups.Text = "Egg Groups: " + string.Join(", ", eggGroupNames);
                }
                //Displays alternate text if no egg groups found
                else
                {
                    lbl_EggGroups.Text = "Egg Groups: No egg groups listed";
                }
            }
            catch (HttpRequestException)
            {
                MessageBox.Show("The Pokemon could not be found.");
            }
        }

        private void btn_Test_Click(object sender, EventArgs e)
        {
            string query = txb_Query.Text;
            GetSpecies(query);
        }
    }
}
