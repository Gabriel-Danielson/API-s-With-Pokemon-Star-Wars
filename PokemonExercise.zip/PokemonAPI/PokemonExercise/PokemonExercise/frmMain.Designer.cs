﻿namespace PokemonExercise
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Search = new System.Windows.Forms.Label();
            this.btn_Confirm = new System.Windows.Forms.Button();
            this.txb_Query = new System.Windows.Forms.TextBox();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Happiness = new System.Windows.Forms.Label();
            this.lbl_CaptureRate = new System.Windows.Forms.Label();
            this.lbl_Habitat = new System.Windows.Forms.Label();
            this.lbl_GrowthRate = new System.Windows.Forms.Label();
            this.lbl_FlavorText = new System.Windows.Forms.Label();
            this.lbl_EggGroups = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Search
            // 
            this.lbl_Search.AutoSize = true;
            this.lbl_Search.Location = new System.Drawing.Point(16, 17);
            this.lbl_Search.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Search.Name = "lbl_Search";
            this.lbl_Search.Size = new System.Drawing.Size(188, 13);
            this.lbl_Search.TabIndex = 0;
            this.lbl_Search.Text = "Search for a Pokemon, by name or ID!";
            // 
            // btn_Confirm
            // 
            this.btn_Confirm.Location = new System.Drawing.Point(25, 45);
            this.btn_Confirm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_Confirm.Name = "btn_Confirm";
            this.btn_Confirm.Size = new System.Drawing.Size(56, 19);
            this.btn_Confirm.TabIndex = 1;
            this.btn_Confirm.Text = "Search";
            this.btn_Confirm.UseVisualStyleBackColor = true;
            this.btn_Confirm.Click += new System.EventHandler(this.btn_Test_Click);
            // 
            // txb_Query
            // 
            this.txb_Query.Location = new System.Drawing.Point(93, 46);
            this.txb_Query.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txb_Query.Name = "txb_Query";
            this.txb_Query.Size = new System.Drawing.Size(102, 20);
            this.txb_Query.TabIndex = 2;
            // 
            // lbl_Name
            // 
            this.lbl_Name.Location = new System.Drawing.Point(238, 12);
            this.lbl_Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(208, 52);
            this.lbl_Name.TabIndex = 3;
            this.lbl_Name.Text = "Name:";
            this.lbl_Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_Happiness
            // 
            this.lbl_Happiness.Location = new System.Drawing.Point(238, 64);
            this.lbl_Happiness.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Happiness.Name = "lbl_Happiness";
            this.lbl_Happiness.Size = new System.Drawing.Size(208, 52);
            this.lbl_Happiness.TabIndex = 4;
            this.lbl_Happiness.Text = "Base Happiness:";
            this.lbl_Happiness.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_CaptureRate
            // 
            this.lbl_CaptureRate.Location = new System.Drawing.Point(238, 116);
            this.lbl_CaptureRate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_CaptureRate.Name = "lbl_CaptureRate";
            this.lbl_CaptureRate.Size = new System.Drawing.Size(209, 52);
            this.lbl_CaptureRate.TabIndex = 5;
            this.lbl_CaptureRate.Text = "Capture Rate:";
            this.lbl_CaptureRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_Habitat
            // 
            this.lbl_Habitat.Location = new System.Drawing.Point(238, 228);
            this.lbl_Habitat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Habitat.Name = "lbl_Habitat";
            this.lbl_Habitat.Size = new System.Drawing.Size(208, 52);
            this.lbl_Habitat.TabIndex = 6;
            this.lbl_Habitat.Text = "Habitat:";
            this.lbl_Habitat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_GrowthRate
            // 
            this.lbl_GrowthRate.Location = new System.Drawing.Point(238, 168);
            this.lbl_GrowthRate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_GrowthRate.Name = "lbl_GrowthRate";
            this.lbl_GrowthRate.Size = new System.Drawing.Size(208, 52);
            this.lbl_GrowthRate.TabIndex = 7;
            this.lbl_GrowthRate.Text = "Growth Rate";
            this.lbl_GrowthRate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_FlavorText
            // 
            this.lbl_FlavorText.Location = new System.Drawing.Point(238, 280);
            this.lbl_FlavorText.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_FlavorText.Name = "lbl_FlavorText";
            this.lbl_FlavorText.Size = new System.Drawing.Size(209, 52);
            this.lbl_FlavorText.TabIndex = 8;
            this.lbl_FlavorText.Text = "Flavor Text:";
            this.lbl_FlavorText.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_EggGroups
            // 
            this.lbl_EggGroups.Location = new System.Drawing.Point(238, 332);
            this.lbl_EggGroups.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_EggGroups.Name = "lbl_EggGroups";
            this.lbl_EggGroups.Size = new System.Drawing.Size(209, 52);
            this.lbl_EggGroups.TabIndex = 9;
            this.lbl_EggGroups.Text = "Egg Groups:";
            this.lbl_EggGroups.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 397);
            this.Controls.Add(this.lbl_EggGroups);
            this.Controls.Add(this.lbl_FlavorText);
            this.Controls.Add(this.lbl_GrowthRate);
            this.Controls.Add(this.lbl_Habitat);
            this.Controls.Add(this.lbl_CaptureRate);
            this.Controls.Add(this.lbl_Happiness);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.txb_Query);
            this.Controls.Add(this.btn_Confirm);
            this.Controls.Add(this.lbl_Search);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmMain";
            this.Text = " Main";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Search;
        private System.Windows.Forms.Button btn_Confirm;
        private System.Windows.Forms.TextBox txb_Query;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Happiness;
        private System.Windows.Forms.Label lbl_CaptureRate;
        private System.Windows.Forms.Label lbl_Habitat;
        private System.Windows.Forms.Label lbl_GrowthRate;
        private System.Windows.Forms.Label lbl_FlavorText;
        private System.Windows.Forms.Label lbl_EggGroups;
    }
}

