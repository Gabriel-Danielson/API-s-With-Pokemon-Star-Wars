﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace StarWarsExercise
{
    public class JSONHelper
    {
        static readonly HttpClient client = new HttpClient();

        /// <summary> Gets information about a planet from API based on ID.</summary>
        /// <param name="planetId">ID of planet you're looking for</param>
        /// <returns>an object containing all of the data around a planet from the API</returns>
        public static async Task<Planet> GetPlanetById(string planetId)
        {
            Planet deserializedPlanet = new Planet();
            // Try/catch block for exceptions
            try
            {
                HttpResponseMessage response = await client.GetAsync($"https://swapi.py4e.com/api/planets/{planetId}/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                deserializedPlanet = JsonConvert.DeserializeObject<Planet>(responseBody);
                return deserializedPlanet;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return deserializedPlanet;
            }
        }

        /// <summary> Gets information about a planet from API based on url.</summary>
        /// <param name="planetUrl">API website url of planet you're looking for</param>
        /// <returns>an object containing all of the data around a planet from the API</returns>
        public static async Task<Planet> GetPlanetByUrl(string planetUrl)
        {
            Planet deserializedPlanet = new Planet();
            // Try/catch block for exceptions
            try
            {
                HttpResponseMessage response = await client.GetAsync(planetUrl);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                deserializedPlanet = JsonConvert.DeserializeObject<Planet>(responseBody);
                return deserializedPlanet;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return deserializedPlanet;
            }
        }

        /// <summary> Gets information about a person from API based on ID.</summary>
        /// <param name="personId">ID of person you're looking for</param>
        /// <returns>an object containing all of the data around a person from the API</returns>
        public static async Task<Person> GetPerson(string personId)
        {
            Person deserializedPerson = new Person();

            // Try/catch block for exceptions
            try
            {
                HttpResponseMessage response = await client.GetAsync($"https://swapi.py4e.com/api/people/{personId}/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                deserializedPerson = JsonConvert.DeserializeObject<Person>(responseBody);
                return deserializedPerson;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return deserializedPerson;
            }
        }

        /// <summary> Gets information about a ship from API based on url.</summary>
        /// <param name="shipUrl">API website url of ship you're looking for</param>
        /// <returns>an object containing all of the data around a starship from the API</returns>
        public static async Task<Starship> GetStarshipByUrl(string shipUrl)
        {
            Starship deserializedStarship = new Starship();

            // Try/catch block for exceptions
            try
            {
                HttpResponseMessage response = await client.GetAsync(shipUrl);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                deserializedStarship = JsonConvert.DeserializeObject<Starship>(responseBody);
                return deserializedStarship;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return deserializedStarship;
            }
        }

        /// <summary> Gets information of all species from API.</summary>
        /// <returns>an object containing all of the data of all species from the API on the first page</returns>
        public static async Task<AllSpecies> GetAllSpecies()
        {
            AllSpecies deserializedAllSpecies = new AllSpecies();

            // Try/catch block for exceptions
            try
            {
                HttpResponseMessage response = await client.GetAsync($"https://swapi.py4e.com/api/species/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                deserializedAllSpecies = JsonConvert.DeserializeObject<AllSpecies>(responseBody);
                return deserializedAllSpecies;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                
                return deserializedAllSpecies;
            }
        }

        /// <summary> Overload function that gets information of all species from API.</summary>
        /// <param name="nextAllSpecies">The API website url of the next page of species</param>
        /// <returns>an object containing all of the data of all species from the API on a specified page</returns>
        public static async Task<AllSpecies> GetAllSpecies(string nextAllSpecies)
        {
            AllSpecies deserializedAllSpecies = new AllSpecies();

            // Try/catch block for exceptions
            try
            {
                HttpResponseMessage response = await client.GetAsync(nextAllSpecies);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                deserializedAllSpecies = JsonConvert.DeserializeObject<AllSpecies>(responseBody);
                return deserializedAllSpecies;
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return deserializedAllSpecies;
            }
        }
    }
}
