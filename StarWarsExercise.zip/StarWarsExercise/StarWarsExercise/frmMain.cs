﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarWarsExercise
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        /// <summary> Button for displaying information about a planet based on ID from a textbox.</summary>
        private async void btn_GetPlanet_Click(object sender, EventArgs e)
        {
            string planetId = txb_PlanetInput.Text;

            // Try/catch block for exceptions
            try
            {
                Planet planet = await JSONHelper.GetPlanetById(planetId);

                //Checks if planet or textbox are valid
                if (planet != null && txb_PlanetInput.Text != "")
                {
                    lbl_Display.Text = "Displaying: Planet";
                    lbx_Display.Items.Clear();
                    lbx_Display.Items.Add($"Name: {planet.name}");
                    lbx_Display.Items.Add($"Orbital Period: {planet.orbital_period} days");
                    lbx_Display.Items.Add($"Diameter: {planet.diameter} km");
                    lbx_Display.Items.Add($"Climate: {planet.climate}");
                    lbx_Display.Items.Add($"Gravity: {planet.gravity} G");
                    lbx_Display.Items.Add($"Terrain: {planet.terrain}");
                    lbx_Display.Items.Add($"Surface Water: {planet.surface_water}%");
                    lbx_Display.Items.Add($"Population: {planet.population}");
                }
                else
                {
                    MessageBox.Show("Please enter a valid ID.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        /// <summary> Button for displaying information about a person based on ID from a textbox.</summary>
        private async void btn_GetPerson_Click(object sender, EventArgs e)
        {
            string personId = txb_PersonInput.Text;

            // Try/catch block for exceptions
            try
            {
                Person person = await JSONHelper.GetPerson(personId);

                //Checks if person or textbox are valid
                if (person != null && txb_PersonInput.Text != "")
                {
                    //Needed to get homeworld name
                    Planet planet = await JSONHelper.GetPlanetByUrl(person.homeworld);

                    //Checks if planet has a value
                    if (planet != null)
                    {
                        lbl_Display.Text = "Displaying: Person";
                        lbx_Display.Items.Clear();
                        lbx_Display.Items.Add($"Name: {person.name}");
                        lbx_Display.Items.Add($"Height: {person.height} cm");
                        lbx_Display.Items.Add($"Mass: {person.mass} kg");
                        lbx_Display.Items.Add($"Hair Color: {person.hair_color}");
                        lbx_Display.Items.Add($"Skin Color: {person.skin_color}");
                        lbx_Display.Items.Add($"Eye Color: {person.eye_color}");
                        lbx_Display.Items.Add($"Birth Year: {person.birth_year}");
                        lbx_Display.Items.Add($"Gender: {person.gender}");
                        lbx_Display.Items.Add($"Homeworld: {planet.name}");
                    }
                    //Iterates to add starships to the display
                    foreach (var ship in person.starships)
                    {
                        string stringShip = Convert.ToString(ship);
                        Starship starship = await JSONHelper.GetStarshipByUrl(stringShip);

                        //Checks if starship has a value
                        if (starship != null)
                        {
                            lbx_Display.Items.Add($"Starship: {starship.name}");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid ID.");
                }    
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        /// <summary> Button for displaying all information on all species.</summary>
        private async void btn_GetSpecies_Click(object sender, EventArgs e)
        {
            lbl_Display.Text = "Displaying: All Species";
            lbx_Display.Items.Clear();

            // Try/catch block for exceptions
            try
            {
                AllSpecies allSpecies = await JSONHelper.GetAllSpecies();

                //Runs as long as there is another page to Species List in API
                while (allSpecies != null && allSpecies.next != null)
                {
                    //Adds species data to display
                    foreach (var species in allSpecies.results)
                    {
                        //Runs if there is a homeworld
                        if (species.homeworld == null)
                        {
                            lbx_Display.Items.Add($"---------------------------------------------");
                            lbx_Display.Items.Add($"Name: {species.name}");
                            lbx_Display.Items.Add($"Classification: {species.classification}");
                            lbx_Display.Items.Add($"Designation: {species.designation}");
                            lbx_Display.Items.Add($"Average Height: {species.average_height} cm");
                            lbx_Display.Items.Add($"Skin Colors: {species.skin_colors}");
                            lbx_Display.Items.Add($"Hair Colors: {species.hair_colors}");
                            lbx_Display.Items.Add($"Eye Colors: {species.eye_colors}");
                            lbx_Display.Items.Add($"Average Lifespan: {species.average_lifespan} years");
                            lbx_Display.Items.Add($"Language: {species.language}");
                            lbx_Display.Items.Add($"Homeworld: {species.homeworld}");
                            lbx_Display.Items.Add($"---------------------------------------------");
                        }
                        //Displays different formatting if no homeworld found
                        else
                        {
                            Planet planet = await JSONHelper.GetPlanetByUrl(species.homeworld);

                            //Checks if planet has a value
                            if (planet != null) ;
                            {
                                lbx_Display.Items.Add($"---------------------------------------------");
                                lbx_Display.Items.Add($"Name: {species.name}");
                                lbx_Display.Items.Add($"Classification: {species.classification}");
                                lbx_Display.Items.Add($"Designation: {species.designation}");
                                lbx_Display.Items.Add($"Average Height: {species.average_height} cm");
                                lbx_Display.Items.Add($"Skin Colors: {species.skin_colors}");
                                lbx_Display.Items.Add($"Hair Colors: {species.hair_colors}");
                                lbx_Display.Items.Add($"Eye Colors: {species.eye_colors}");
                                lbx_Display.Items.Add($"Average Lifespan: {species.average_lifespan} years");
                                lbx_Display.Items.Add($"Language: {species.language}");
                                lbx_Display.Items.Add($"Homeworld: {planet.name}");
                                lbx_Display.Items.Add($"---------------------------------------------");
                            }
                        }
                    }

                    allSpecies = await JSONHelper.GetAllSpecies(allSpecies.next);
                }

                //Displays the last page of species  
                if (allSpecies != null)
                {
                    //overload
                    foreach (var species in allSpecies.results)
                    {
                        //Runs if there is a homeworld
                        if (species.homeworld == null)
                        {
                            lbx_Display.Items.Add($"---------------------------------------------");
                            lbx_Display.Items.Add($"Name: {species.name}");
                            lbx_Display.Items.Add($"Classification: {species.classification}");
                            lbx_Display.Items.Add($"Designation: {species.designation}");
                            lbx_Display.Items.Add($"Average Height: {species.average_height} cm");
                            lbx_Display.Items.Add($"Skin Colors: {species.skin_colors}");
                            lbx_Display.Items.Add($"Hair Colors: {species.hair_colors}");
                            lbx_Display.Items.Add($"Eye Colors: {species.eye_colors}");
                            lbx_Display.Items.Add($"Average Lifespan: {species.average_lifespan} years");
                            lbx_Display.Items.Add($"Language: {species.language}");
                            lbx_Display.Items.Add($"Homeworld: {species.homeworld}");
                            lbx_Display.Items.Add($"---------------------------------------------");
                        }
                        //Displays different formatting if no homeworld found
                        else
                        {
                            Planet planet = await JSONHelper.GetPlanetByUrl(species.homeworld);

                            //Checks if planet has a value
                            if (planet != null)
                            {
                                lbx_Display.Items.Add($"---------------------------------------------");
                                lbx_Display.Items.Add($"Name: {species.name}");
                                lbx_Display.Items.Add($"Classification: {species.classification}");
                                lbx_Display.Items.Add($"Designation: {species.designation}");
                                lbx_Display.Items.Add($"Average Height: {species.average_height} cm");
                                lbx_Display.Items.Add($"Skin Colors: {species.skin_colors}");
                                lbx_Display.Items.Add($"Hair Colors: {species.hair_colors}");
                                lbx_Display.Items.Add($"Eye Colors: {species.eye_colors}");
                                lbx_Display.Items.Add($"Average Lifespan: {species.average_lifespan} years");
                                lbx_Display.Items.Add($"Language: {species.language}");
                                lbx_Display.Items.Add($"Homeworld: {planet.name}");
                                lbx_Display.Items.Add($"---------------------------------------------");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
    }
}
