﻿namespace StarWarsExercise
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_GetPlanet = new System.Windows.Forms.Button();
            this.btn_GetPerson = new System.Windows.Forms.Button();
            this.btn_GetSpecies = new System.Windows.Forms.Button();
            this.lbl_Planet = new System.Windows.Forms.Label();
            this.txb_PlanetInput = new System.Windows.Forms.TextBox();
            this.txb_PersonInput = new System.Windows.Forms.TextBox();
            this.lbl_Person = new System.Windows.Forms.Label();
            this.lbx_Display = new System.Windows.Forms.ListBox();
            this.lbl_Display = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_GetPlanet
            // 
            this.btn_GetPlanet.Location = new System.Drawing.Point(22, 53);
            this.btn_GetPlanet.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_GetPlanet.Name = "btn_GetPlanet";
            this.btn_GetPlanet.Size = new System.Drawing.Size(111, 50);
            this.btn_GetPlanet.TabIndex = 0;
            this.btn_GetPlanet.Text = "Get Planet";
            this.btn_GetPlanet.UseVisualStyleBackColor = true;
            this.btn_GetPlanet.Click += new System.EventHandler(this.btn_GetPlanet_Click);
            // 
            // btn_GetPerson
            // 
            this.btn_GetPerson.Location = new System.Drawing.Point(22, 148);
            this.btn_GetPerson.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_GetPerson.Name = "btn_GetPerson";
            this.btn_GetPerson.Size = new System.Drawing.Size(111, 50);
            this.btn_GetPerson.TabIndex = 1;
            this.btn_GetPerson.Text = "Get Person";
            this.btn_GetPerson.UseVisualStyleBackColor = true;
            this.btn_GetPerson.Click += new System.EventHandler(this.btn_GetPerson_Click);
            // 
            // btn_GetSpecies
            // 
            this.btn_GetSpecies.Location = new System.Drawing.Point(22, 238);
            this.btn_GetSpecies.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_GetSpecies.Name = "btn_GetSpecies";
            this.btn_GetSpecies.Size = new System.Drawing.Size(111, 50);
            this.btn_GetSpecies.TabIndex = 2;
            this.btn_GetSpecies.Text = "Get All Species";
            this.btn_GetSpecies.UseVisualStyleBackColor = true;
            this.btn_GetSpecies.Click += new System.EventHandler(this.btn_GetSpecies_Click);
            // 
            // lbl_Planet
            // 
            this.lbl_Planet.AutoSize = true;
            this.lbl_Planet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Planet.Location = new System.Drawing.Point(142, 58);
            this.lbl_Planet.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Planet.Name = "lbl_Planet";
            this.lbl_Planet.Size = new System.Drawing.Size(107, 17);
            this.lbl_Planet.TabIndex = 4;
            this.lbl_Planet.Text = "Enter Planet ID:";
            // 
            // txb_PlanetInput
            // 
            this.txb_PlanetInput.Location = new System.Drawing.Point(145, 77);
            this.txb_PlanetInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txb_PlanetInput.Name = "txb_PlanetInput";
            this.txb_PlanetInput.Size = new System.Drawing.Size(88, 20);
            this.txb_PlanetInput.TabIndex = 5;
            // 
            // txb_PersonInput
            // 
            this.txb_PersonInput.Location = new System.Drawing.Point(145, 172);
            this.txb_PersonInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txb_PersonInput.Name = "txb_PersonInput";
            this.txb_PersonInput.Size = new System.Drawing.Size(88, 20);
            this.txb_PersonInput.TabIndex = 6;
            // 
            // lbl_Person
            // 
            this.lbl_Person.AutoSize = true;
            this.lbl_Person.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Person.Location = new System.Drawing.Point(142, 154);
            this.lbl_Person.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Person.Name = "lbl_Person";
            this.lbl_Person.Size = new System.Drawing.Size(112, 17);
            this.lbl_Person.TabIndex = 8;
            this.lbl_Person.Text = "Enter Person ID:";
            // 
            // lbx_Display
            // 
            this.lbx_Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbx_Display.FormattingEnabled = true;
            this.lbx_Display.ItemHeight = 20;
            this.lbx_Display.Location = new System.Drawing.Point(252, 30);
            this.lbx_Display.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbx_Display.Name = "lbx_Display";
            this.lbx_Display.Size = new System.Drawing.Size(395, 264);
            this.lbx_Display.TabIndex = 10;
            // 
            // lbl_Display
            // 
            this.lbl_Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Display.Location = new System.Drawing.Point(252, 7);
            this.lbl_Display.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Display.Name = "lbl_Display";
            this.lbl_Display.Size = new System.Drawing.Size(395, 20);
            this.lbl_Display.TabIndex = 11;
            this.lbl_Display.Text = "Displaying: None";
            this.lbl_Display.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 306);
            this.Controls.Add(this.lbl_Display);
            this.Controls.Add(this.lbx_Display);
            this.Controls.Add(this.lbl_Person);
            this.Controls.Add(this.txb_PersonInput);
            this.Controls.Add(this.txb_PlanetInput);
            this.Controls.Add(this.lbl_Planet);
            this.Controls.Add(this.btn_GetSpecies);
            this.Controls.Add(this.btn_GetPerson);
            this.Controls.Add(this.btn_GetPlanet);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_GetPlanet;
        private System.Windows.Forms.Button btn_GetPerson;
        private System.Windows.Forms.Button btn_GetSpecies;
        private System.Windows.Forms.Label lbl_Planet;
        private System.Windows.Forms.TextBox txb_PlanetInput;
        private System.Windows.Forms.TextBox txb_PersonInput;
        private System.Windows.Forms.Label lbl_Person;
        private System.Windows.Forms.ListBox lbx_Display;
        private System.Windows.Forms.Label lbl_Display;
    }
}

